package com.selfMess.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
