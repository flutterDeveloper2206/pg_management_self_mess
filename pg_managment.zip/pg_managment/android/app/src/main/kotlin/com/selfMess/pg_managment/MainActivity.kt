package com.selfMess.pg_managment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
