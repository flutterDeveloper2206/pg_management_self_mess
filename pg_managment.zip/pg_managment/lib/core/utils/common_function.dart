

String meterToKm(double? meter){

  return (meter!/1000).toStringAsFixed(1);
}

bool isLogPrint = true;