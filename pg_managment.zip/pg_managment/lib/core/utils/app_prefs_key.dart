/// [PrefsKey] contains key names which have been used to store data
/// with [Hive]

abstract class PrefsKey {
  // static const String user = '@lmg_user';
}
