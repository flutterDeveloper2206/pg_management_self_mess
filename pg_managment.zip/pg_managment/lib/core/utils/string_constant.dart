class StringConstants {

 static String authToken = 'auth_token';
 static String studentId = 'student_id';
 static String isStudent = 'isStudent';
 static String totalDays = 'totalDays';
 static String penalty = 'penalty';
 static String eatenDays = 'eatenDays';
 static String simpleGuest = 'simpleGuest';
 static String feastGuest = 'feastGuest';


}