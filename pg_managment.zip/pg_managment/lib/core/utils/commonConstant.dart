

class CommonConstant {
  CommonConstant._();

  String mapApiKey = '';

  static final instance = CommonConstant._();




int isStudent = 1;


}
