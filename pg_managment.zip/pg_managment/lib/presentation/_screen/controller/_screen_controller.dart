

import 'package:get/get.dart';

class ScreenController extends GetxController {



}
